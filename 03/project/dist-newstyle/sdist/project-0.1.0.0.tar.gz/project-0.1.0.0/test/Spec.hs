import Lib 
import Data.Function (on)
import Test.QuickCheck  

main:: IO ()
main = putStrLn "Test suite not yet implementer"

prop_conversions :: [Int] -> Bool 
prop_conversions lst = lst == (toList $ fromList $ lst)  
-- prop_conversions = (==) (toList $ fromList $ lst)

-- toList . fromList :: [a] -> [a]
-- toList :: Ring a -> [a]
-- fromList :: [a] -> Ring a 

-- [a] -> [a]

